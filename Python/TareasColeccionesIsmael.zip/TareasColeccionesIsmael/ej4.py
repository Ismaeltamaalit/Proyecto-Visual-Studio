alumnos = {}

alumnos[123] = {
    "Nombre": "Ana",
    "Apellidos": "García López",
    "Teléfono": "600111222",
    "Asistencia": [("2024-05-01", True), ("2024-05-02", False)]
}

alumnos[456] = {
    "Nombre": "Luis",
    "Apellidos": "Martínez Ruiz",
    "Teléfono": "600333444",
    "Asistencia": [("2024-05-01", True), ("2024-05-02", True)]
}

print(alumnos)